资料分析试卷包（示例）

结构：
  试卷.xlsx                    试卷主数据（统一 Excel 模板，材料里引用 images/资料分析折线图.png）
  images/资料分析折线图.png    材料配图
  README.txt                   这个文件，不参与导入（也可以删）

怎么用：
  1. 把 试卷.xlsx 换成你自己的（模板见仓库 templates/试卷模板.xlsx）；
  2. 图片放进 images/（文件名任意，Excel 的「材料 / 图片」列里写 images/xxx.png 这样的相对路径）；
  3. 整个文件夹压成 zip（外层多包一层文件夹也没关系）；
  4. App 里「导入」选这个 zip。
